const express = require('express'), Database = require('better-sqlite3'), bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'), cookieParser = require('cookie-parser'), path = require('path');

const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 16) { console.error('Set JWT_SECRET (16+ chars) in .env'); process.exit(1); }

const db = new Database(path.join(__dirname, 'data.db'));
db.exec(`
create table if not exists users(id integer primary key, name text not null, email text unique not null, hash text not null);
create table if not exists items(id integer primary key, kind text not null, user_id integer not null, data text not null, done integer default 0);
create table if not exists messages(id integer primary key, user_id integer, name text, text text not null);`);

const app = express();
app.use(express.json({ limit: '50kb' }), cookieParser());

const KINDS = new Set(['assignment', 'book', 'track', 'resource']);
const SHARED = new Set(['resource']); // visible to everyone; others are private per user

const setSession = (res, id) => res.cookie('token', jwt.sign({ id }, SECRET, { expiresIn: '7d' }),
  { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7 * 864e5 });

function requireUser(req, res, next) {
  try {
    const { id } = jwt.verify(req.cookies.token, SECRET);
    req.user = db.prepare('select id, name, email from users where id = ?').get(id);
    if (!req.user) throw new Error();
    next();
  } catch { res.status(401).json({ error: 'Please log in.' }); }
}

// ---- auth ----
app.post('/api/signup', (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 60) || 'Student';
  const email = String(req.body.email || '').trim().toLowerCase();
  const pw = String(req.body.password || '');
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (pw.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if (db.prepare('select 1 from users where email = ?').get(email))
    return res.status(409).json({ error: 'That email already has an account. Log in instead.' });
  const id = db.prepare('insert into users(name,email,hash) values(?,?,?)').run(name, email, bcrypt.hashSync(pw, 10)).lastInsertRowid;
  setSession(res, id); res.json({ id, name, email });
});

app.post('/api/login', (req, res) => {
  const u = db.prepare('select * from users where email = ?').get(String(req.body.email || '').trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(req.body.password || ''), u.hash))
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  setSession(res, u.id); res.json({ id: u.id, name: u.name, email: u.email });
});

app.post('/api/logout', (req, res) => { res.clearCookie('token'); res.json({ ok: true }); });
app.get('/api/me', requireUser, (req, res) => res.json(req.user));

// ---- items: assignments, books, tracks (private) and library resources (shared) ----
const clean = d => Object.fromEntries(Object.entries(d || {}).slice(0, 8).map(([k, v]) => [k.slice(0, 20), String(v).slice(0, 300)]));

app.get('/api/items/:kind', requireUser, (req, res) => {
  const k = req.params.kind; if (!KINDS.has(k)) return res.sendStatus(404);
  const rows = SHARED.has(k)
    ? db.prepare('select * from items where kind = ? order by id desc').all(k)
    : db.prepare('select * from items where kind = ? and user_id = ? order by id desc').all(k, req.user.id);
  res.json(rows.map(r => ({ id: r.id, done: !!r.done, mine: r.user_id === req.user.id, data: JSON.parse(r.data) })));
});

app.post('/api/items/:kind', requireUser, (req, res) => {
  const k = req.params.kind; if (!KINDS.has(k)) return res.sendStatus(404);
  const data = clean(req.body.data);
  if (!data.title || !data.title.trim()) return res.status(400).json({ error: 'A title is required.' });
  const id = db.prepare('insert into items(kind,user_id,data) values(?,?,?)').run(k, req.user.id, JSON.stringify(data)).lastInsertRowid;
  res.json({ id });
});

app.patch('/api/items/:id', requireUser, (req, res) => {
  const r = db.prepare('update items set done = ? where id = ? and user_id = ?').run(req.body.done ? 1 : 0, req.params.id, req.user.id);
  r.changes ? res.json({ ok: true }) : res.sendStatus(404);
});

app.delete('/api/items/:id', requireUser, (req, res) => {
  const r = db.prepare('delete from items where id = ? and user_id = ?').run(req.params.id, req.user.id);
  r.changes ? res.json({ ok: true }) : res.sendStatus(404);
});

// ---- chat (shared room, clients poll) ----
app.get('/api/chat', requireUser, (req, res) => {
  const after = parseInt(req.query.after) || 0;
  res.json(db.prepare('select * from (select id,user_id,name,text from messages where id > ? order by id desc limit 100) order by id').all(after));
});

app.post('/api/chat', requireUser, (req, res) => {
  const text = String(req.body.text || '').trim().slice(0, 500);
  if (!text) return res.status(400).json({ error: 'Message is empty.' });
  res.json({ id: db.prepare('insert into messages(user_id,name,text) values(?,?,?)').run(req.user.id, req.user.name, text).lastInsertRowid });
});

// ---- AI helper: key stays on the server ----
app.post('/api/ai', requireUser, async (req, res) => {
  if (!process.env.ANTHROPIC_API_KEY) return res.status(503).json({ error: 'AI is not set up. Add ANTHROPIC_API_KEY to .env and restart.' });
  const messages = (Array.isArray(req.body.messages) ? req.body.messages : []).slice(-20)
    .map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 4000) }));
  if (!messages.length || messages[messages.length - 1].role !== 'user') return res.status(400).json({ error: 'Send a question first.' });
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.AI_MODEL || 'claude-sonnet-5-5', max_tokens: 1000,
        system: 'You are a patient study helper for students. Explain clearly, check understanding, and do not just hand over answers to graded work.', messages })
    });
    const j = await r.json();
    if (!r.ok) return res.status(502).json({ error: j.error?.message || 'The AI service returned an error.' });
    res.json({ text: j.content.filter(b => b.type === 'text').map(b => b.text).join('\n') });
  } catch { res.status(502).json({ error: 'Could not reach the AI service.' }); }
});

// ---- static files: only the public folders, never server.js, .env or data.db ----
for (const d of ['css', 'js', 'assets', 'pages']) app.use('/' + d, express.static(path.join(__dirname, d)));
for (const f of ['index', 'login', 'dashboard']) app.get(f === 'index' ? '/' : `/${f}.html`, (q, r) => r.sendFile(path.join(__dirname, f + '.html')));

app.listen(process.env.PORT || 3000, () => console.log('Running at http://localhost:' + (process.env.PORT || 3000)));
