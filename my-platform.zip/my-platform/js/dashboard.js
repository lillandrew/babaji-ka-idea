const links = [
  ['Dashboard', 'dashboard.html', 'Your overview'], ['Chat', 'pages/chat.html', 'Talk with your class'],
  ['Library', 'pages/library.html', 'Shared notes and resources'], ['Assignments', 'pages/assignments.html', 'Track what is due'],
  ['AI helper', 'pages/ai.html', 'Ask study questions'], ['Books', 'pages/books.html', 'Your reading list'],
  ['Music', 'pages/music.html', 'Your focus playlists']
].map(l => [l[0], ROOT + l[1], l[2]]);
Auth.ready.then(me => {
  const here = location.pathname.split('/').pop();
  document.getElementById('sidebar').innerHTML = '<div class="brand">My Platform</div>' +
    links.map(l => `<a href="${l[1]}" class="${l[1].endsWith(here) ? 'active' : ''}">${l[0]}</a>`).join('') +
    '<button class="btn ghost" id="logout">Log out</button>';
  document.getElementById('logout').onclick = () => Auth.logout();
  const tiles = document.getElementById('tiles');
  if (tiles) {
    document.getElementById('hello').textContent = 'Hi, ' + me.name;
    tiles.innerHTML = links.slice(1).map(l => `<a class="card" href="${l[1]}"><h3>${l[0]}</h3><p>${l[2]}</p></a>`).join('');
  }
});
