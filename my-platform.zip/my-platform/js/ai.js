const box = document.getElementById('msgs'), input = document.getElementById('text'), history = [];
function add(role, text) {
  const d = document.createElement('div'); d.className = 'msg' + (role === 'user' ? ' me' : ''); d.textContent = text;
  d.style.whiteSpace = 'pre-wrap'; box.append(d); box.scrollTop = box.scrollHeight; return d;
}
box.innerHTML = '<div class="empty">Ask anything about your coursework.</div>';
document.getElementById('chatForm').onsubmit = async e => {
  e.preventDefault();
  const text = input.value.trim(); if (!text) return;
  if (!history.length) box.innerHTML = '';
  input.value = ''; history.push({ role: 'user', content: text }); add('user', text);
  const wait = add('assistant', 'Thinking...');
  try { const r = await api('/api/ai', 'POST', { messages: history }); wait.textContent = r.text; history.push({ role: 'assistant', content: r.text }); }
  catch (err) { wait.textContent = err.message; history.pop(); }
};
