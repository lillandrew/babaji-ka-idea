// One engine for Assignments, Books, Music and Library. The page's data-kind picks the config.
const CFG = {
  assignment: { fields: [['title', 'Assignment'], ['due', 'Due date', 'date']], meta: d => d.due && 'Due ' + d.due, check: 'Done', empty: 'No assignments yet. Add one above.' },
  book: { fields: [['title', 'Title'], ['author', 'Author']], meta: d => d.author, check: 'Finished', empty: 'Your reading list is empty. Add a book above.' },
  track: { fields: [['title', 'Track or playlist'], ['url', 'Link (https://...)', 'url']], meta: d => '', check: null, empty: 'No tracks yet. Add a link above.' },
  resource: { fields: [['title', 'Title'], ['subject', 'Subject'], ['desc', 'Short description']], meta: d => d.subject, check: null, search: true, empty: 'Nothing here yet. Add the first resource.' }
};
const root = document.querySelector('[data-kind]'), kind = root.dataset.kind, cfg = CFG[kind];
const list = document.getElementById('list'), formEl = document.getElementById('addForm'), q = document.getElementById('q');
let items = [];

formEl.innerHTML = cfg.fields.map(f => `<input name="${f[0]}" type="${f[2] || 'text'}" placeholder="${f[1]}" aria-label="${f[1]}" ${f[0] === 'title' ? 'required' : ''}>`).join('') + '<button class="btn">Add</button>';
formEl.onsubmit = async e => {
  e.preventDefault();
  try { await api('/api/items/' + kind, 'POST', { data: Object.fromEntries(new FormData(formEl)) }); formEl.reset(); load(); }
  catch (err) { alert(err.message); }
};

function draw() {
  const s = q ? q.value.toLowerCase() : '';
  let rows = items.filter(i => !s || Object.values(i.data).join(' ').toLowerCase().includes(s));
  if (kind === 'assignment') rows.sort((a, b) => (a.done - b.done) || (a.data.due || '9').localeCompare(b.data.due || '9'));
  list.innerHTML = '';
  if (!rows.length) { list.innerHTML = `<div class="empty">${s ? 'Nothing matches that search.' : cfg.empty}</div>`; return; }
  rows.forEach(i => {
    const d = i.data, el = document.createElement('div'); el.className = 'card item' + (i.done ? ' done' : '');
    const body = document.createElement('div'), t = /^https?:\/\//i.test(d.url || '') ? document.createElement('a') : document.createElement('strong');
    t.textContent = d.title; if (t.tagName === 'A') { t.href = d.url; t.target = '_blank'; t.rel = 'noopener noreferrer'; }
    body.append(t);
    const sub = [cfg.meta(d), d.desc].filter(Boolean).join(' · ');
    if (sub) { const p = document.createElement('p'); p.textContent = sub; body.append(p); }
    el.append(body);
    if (cfg.check && i.mine) {
      const b = document.createElement('button'); b.className = 'btn ghost'; b.textContent = i.done ? 'Undo' : cfg.check;
      b.onclick = async () => { await api('/api/items/' + i.id, 'PATCH', { done: !i.done }); load(); }; el.append(b);
    }
    if (i.mine) {
      const x = document.createElement('button'); x.className = 'btn ghost'; x.textContent = 'Delete';
      x.onclick = async () => { if (confirm('Delete "' + d.title + '"?')) { await api('/api/items/' + i.id, 'DELETE'); load(); } }; el.append(x);
    }
    list.append(el);
  });
}
async function load() { items = await api('/api/items/' + kind); draw(); }
if (q) q.oninput = draw;
Auth.ready.then(load);
