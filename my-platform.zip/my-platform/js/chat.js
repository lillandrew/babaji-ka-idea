// Shared room: everyone sees the same messages. Polls the server every 2 seconds.
const box = document.getElementById('msgs'), input = document.getElementById('text');
let last = 0, myId;
function add(m) {
  const d = document.createElement('div'); d.className = 'msg' + (m.user_id === myId ? ' me' : '');
  const s = document.createElement('small'); s.textContent = m.name;
  d.append(s, document.createTextNode(m.text)); box.append(d);
}
async function poll() {
  try {
    const msgs = await api('/api/chat?after=' + last);
    if (!msgs.length) return;
    if (!last) box.innerHTML = '';
    msgs.forEach(add); last = msgs[msgs.length - 1].id; box.scrollTop = box.scrollHeight;
  } catch {}
}
Auth.ready.then(me => {
  myId = me.id;
  box.innerHTML = '<div class="empty">No messages yet. Say hello.</div>';
  poll(); setInterval(poll, 2000);
  document.getElementById('chatForm').onsubmit = async e => {
    e.preventDefault();
    const text = input.value.trim(); if (!text) return;
    input.value = ''; await api('/api/chat', 'POST', { text }).catch(() => (input.value = text)); poll();
  };
});
