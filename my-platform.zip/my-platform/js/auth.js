// Talks to the real server. Passwords are hashed on the server; the session is an httpOnly cookie.
async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Something went wrong. Try again.');
  return j;
}
const ROOT = location.pathname.includes('/pages/') ? '../' : '';
const Auth = {
  ready: null,
  async logout() { await api('/api/logout', 'POST').catch(() => {}); location.href = ROOT + 'login.html'; }
};
const form = document.getElementById('authForm');

if (!form) { // every signed-in page: wait for the server to confirm the session
  Auth.ready = api('/api/me').catch(() => { location.href = ROOT + 'login.html'; return new Promise(() => {}); });
} else {
  const $ = id => document.getElementById(id);
  const mode = () => (location.hash === '#signup' ? 'signup' : 'login');
  const render = () => {
    const s = mode() === 'signup';
    $('title').textContent = $('submit').textContent = s ? 'Create account' : 'Log in';
    $('hint').textContent = s ? 'Takes under a minute.' : 'Welcome back.';
    $('nameRow').hidden = !s;
    $('password').autocomplete = s ? 'new-password' : 'current-password';
    $('toggle').textContent = s ? 'Have an account? Log in' : 'New here? Create an account';
    $('toggle').href = s ? '#login' : '#signup';
    $('error').textContent = '';
  };
  window.addEventListener('hashchange', render); render();
  form.onsubmit = async e => {
    e.preventDefault(); $('submit').disabled = true;
    try {
      await api(mode() === 'signup' ? '/api/signup' : '/api/login', 'POST',
        { name: $('name').value, email: $('email').value, password: $('password').value });
      location.href = 'dashboard.html';
    } catch (err) { $('error').textContent = err.message; }
    $('submit').disabled = false;
  };
}
